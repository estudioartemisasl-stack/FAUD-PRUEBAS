import React, { useState } from 'react';
import {
  Undo2,
  Redo2,
  Search,
  Type,
  Baseline,
  CaseSensitive,
  AlignLeft,
  Sparkles
} from 'lucide-react';
import { toast } from './Toast';

export function EditorToolbar({
  onUndo,
  onRedo,
  canUndo,
  canRedo,
  onTransformText,
  disabled = false
}) {
  const [searchTerm, setSearchTerm] = useState('');
  const [replaceTerm, setReplaceTerm] = useState('');

  const handleCaseUpper = () => {
    onTransformText((text) => text.toUpperCase());
    toast.info('Texto convertido a MAYÚSCULAS');
  };

  const handleCaseLower = () => {
    onTransformText((text) => text.toLowerCase());
    toast.info('Texto convertido a minúsculas');
  };

  const handleCaseTitle = () => {
    onTransformText((text) =>
      text.replace(/\w\S*/g, (txt) => txt.charAt(0).toUpperCase() + txt.substring(1).toLowerCase())
    );
    toast.info('Palabras capitalizadas');
  };

  const handleCleanSpaces = () => {
    onTransformText((text) =>
      text
        .split('\n')
        .map((line) => line.replace(/[ \t]+/g, ' ').trim())
        .join('\n')
        .replace(/\n{3,}/g, '\n\n')
    );
    toast.success('Espacios y líneas vacías depuradas');
  };

  const handleReplaceAll = () => {
    if (!searchTerm.trim()) {
      toast.error('Escribe qué buscar');
      return;
    }

    let count = 0;
    onTransformText((text) => {
      const escaped = searchTerm.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const regex = new RegExp(escaped, 'g');
      const matches = text.match(regex);
      count = matches ? matches.length : 0;
      if (count === 0) return text;
      return text.replace(regex, replaceTerm);
    });

    if (count > 0) {
      toast.success(`${count} reemplazo(s) realizado(s)`);
    } else {
      toast.info('Sin coincidencias encontradas');
    }
  };

  return (
    <div className="flex flex-wrap items-center gap-1.5 p-2 rounded-lg border border-zinc-200 bg-zinc-50/70 text-xs">
      {/* Undo / Redo */}
      <button
        type="button"
        onClick={onUndo}
        disabled={disabled || !canUndo}
        title="Deshacer (Ctrl+Z)"
        className="p-1.5 rounded hover:bg-zinc-200/80 text-zinc-700 disabled:opacity-30 disabled:pointer-events-none transition"
      >
        <Undo2 className="w-3.5 h-3.5" />
      </button>
      <button
        type="button"
        onClick={onRedo}
        disabled={disabled || !canRedo}
        title="Rehacer (Ctrl+Y)"
        className="p-1.5 rounded hover:bg-zinc-200/80 text-zinc-700 disabled:opacity-30 disabled:pointer-events-none transition"
      >
        <Redo2 className="w-3.5 h-3.5" />
      </button>

      <span className="h-4 w-px bg-zinc-300 mx-1" />

      {/* Case transformations */}
      <button
        type="button"
        onClick={handleCaseUpper}
        disabled={disabled}
        title="MAYÚSCULAS"
        className="p-1.5 rounded hover:bg-zinc-200/80 text-zinc-700 disabled:opacity-30 transition font-bold"
      >
        AA
      </button>
      <button
        type="button"
        onClick={handleCaseLower}
        disabled={disabled}
        title="minúsculas"
        className="p-1.5 rounded hover:bg-zinc-200/80 text-zinc-700 disabled:opacity-30 transition font-medium"
      >
        aa
      </button>
      <button
        type="button"
        onClick={handleCaseTitle}
        disabled={disabled}
        title="Capitalizar Palabras"
        className="p-1.5 rounded hover:bg-zinc-200/80 text-zinc-700 disabled:opacity-30 transition font-medium"
      >
        Aa
      </button>
      <button
        type="button"
        onClick={handleCleanSpaces}
        disabled={disabled}
        title="Limpiar espacios y líneas sobrantes"
        className="flex items-center gap-1 px-2 py-1 rounded hover:bg-zinc-200/80 text-zinc-700 disabled:opacity-30 transition"
      >
        <AlignLeft className="w-3.5 h-3.5" />
        <span>Limpiar espacios</span>
      </button>

      <span className="h-4 w-px bg-zinc-300 mx-1" />

      {/* Search & Replace */}
      <div className="flex flex-1 flex-wrap items-center gap-1.5 min-w-[280px]">
        <div className="relative flex-1 min-w-[110px]">
          <Search className="w-3 h-3 text-zinc-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Buscar..."
            disabled={disabled}
            className="w-full pl-7 pr-2 py-1 text-xs rounded border border-zinc-200 bg-white focus:outline-none focus:border-zinc-400 text-zinc-800"
          />
        </div>

        <input
          type="text"
          value={replaceTerm}
          onChange={(e) => setReplaceTerm(e.target.value)}
          placeholder="Reemplazar por..."
          disabled={disabled}
          className="flex-1 min-w-[110px] px-2 py-1 text-xs rounded border border-zinc-200 bg-white focus:outline-none focus:border-zinc-400 text-zinc-800"
        />

        <button
          type="button"
          onClick={handleReplaceAll}
          disabled={disabled || !searchTerm}
          className="px-2.5 py-1 text-xs font-medium rounded border border-zinc-300 bg-white hover:bg-zinc-100 text-zinc-800 disabled:opacity-40 transition shadow-2xs"
        >
          Reemplazar todo
        </button>
      </div>
    </div>
  );
}
