import React, { useState, useEffect, useRef } from 'react';
import {
  Wand2,
  FileText,
  Copy,
  Download,
  FileDown,
  Bookmark,
  Trash2,
  Sparkles,
  Loader2,
  Check,
  Music,
  Globe,
  Share2,
  Play
} from 'lucide-react';
import { Header } from './components/Header';
import { FileUploadDropzone } from './components/FileUploadDropzone';
import { EditorToolbar } from './components/EditorToolbar';
import { ApiKeyModal } from './components/ApiKeyModal';
import { ToastContainer, toast } from './components/Toast';
import { PDF_TEMPLATES, exportToPdf } from './lib/pdfGenerator';
import { refineTranscript } from './lib/refineClient';
import { transcribeAudio } from './lib/audioTranscriber';
import { SAMPLE_TEMPLATES, SAMPLE_TRANSCRIPT } from './lib/defaultTemplates';

const STORAGE_SAVED_EXAMPLE_KEY = 'refinador_saved_example_template';
const STORAGE_GEMINI_KEY = 'gemini_api_key';

export default function App() {
  // Inputs
  const [transcript, setTranscript] = useState('');
  const [example, setExample] = useState('');
  const [hasSavedTemplate, setHasSavedTemplate] = useState(false);

  // Audio State
  const [loadedAudio, setLoadedAudio] = useState(null);
  const [isTranscribingAudio, setIsTranscribingAudio] = useState(false);

  // Result & Editor State
  const [result, setResult] = useState('');
  const [isRefining, setIsRefining] = useState(false);

  // Undo / Redo history
  const [history, setHistory] = useState(['']);
  const [historyIndex, setHistoryIndex] = useState(0);

  // PDF Export Settings
  const [pdfTemplate, setPdfTemplate] = useState('interview');
  const [pdfTitle, setPdfTitle] = useState('Transcripción de Entrevista');
  const [pdfSubtitle, setPdfSubtitle] = useState('');

  // Modals
  const [isApiKeyModalOpen, setIsApiKeyModalOpen] = useState(false);
  const [isDeployModalOpen, setIsDeployModalOpen] = useState(false);
  const [apiKey, setApiKey] = useState('');

  const editorRef = useRef(null);
  const abortControllerRef = useRef(null);

  // Initialize from localStorage
  useEffect(() => {
    const savedTmpl = localStorage.getItem(STORAGE_SAVED_EXAMPLE_KEY);
    if (savedTmpl) {
      setExample(savedTmpl);
      setHasSavedTemplate(true);
    } else {
      setExample(SAMPLE_TEMPLATES[0].text);
    }

    const savedKey = localStorage.getItem(STORAGE_GEMINI_KEY);
    if (savedKey) {
      setApiKey(savedKey);
    }
  }, []);

  // Update text with undo/redo history tracking
  const updateResultWithHistory = (newText, pushToHistory = true) => {
    setResult(newText);
    if (pushToHistory) {
      const newHistory = history.slice(0, historyIndex + 1);
      newHistory.push(newText);
      setHistory(newHistory);
      setHistoryIndex(newHistory.length - 1);
    }
  };

  const handleUndo = () => {
    if (historyIndex > 0) {
      const newIdx = historyIndex - 1;
      setHistoryIndex(newIdx);
      setResult(history[newIdx]);
    }
  };

  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      const newIdx = historyIndex + 1;
      setHistoryIndex(newIdx);
      setResult(history[newIdx]);
    }
  };

  const handleKeyDown = (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'z') {
      if (e.shiftKey) {
        e.preventDefault();
        handleRedo();
      } else {
        e.preventDefault();
        handleUndo();
      }
    } else if ((e.ctrlKey || e.metaKey) && e.key === 'y') {
      e.preventDefault();
      handleRedo();
    }
  };

  // Save / Clear default template
  const handleSaveDefaultExample = () => {
    if (!example.trim()) {
      toast.error('Carga primero un ejemplo antes de guardarlo');
      return;
    }
    localStorage.setItem(STORAGE_SAVED_EXAMPLE_KEY, example);
    setHasSavedTemplate(true);
    toast.success('Ejemplo guardado como plantilla predeterminada');
  };

  const handleClearDefaultExample = () => {
    localStorage.removeItem(STORAGE_SAVED_EXAMPLE_KEY);
    setHasSavedTemplate(false);
    toast.success('Plantilla predeterminada eliminada');
  };

  // Audio Handling & Transcription
  const handleAudioLoaded = (fileOrBlob, defaultName = 'audio.mp3') => {
    const name = fileOrBlob.name || defaultName;
    const sizeMb = (fileOrBlob.size / (1024 * 1024)).toFixed(2);
    setLoadedAudio({
      blob: fileOrBlob,
      name,
      sizeMb,
      mimeType: fileOrBlob.type || 'audio/mp3'
    });
    toast.success(`Audio detectado: ${name} (${sizeMb} MB)`);
  };

  const handleTranscribeAudioOnly = async () => {
    if (!loadedAudio) {
      toast.error('Carga primero un archivo de audio o graba uno.');
      return;
    }

    setIsTranscribingAudio(true);
    toast.info('Transcribiendo audio con IA (esto puede tomar unos segundos)...');

    try {
      const rawText = await transcribeAudio({
        audioBlob: loadedAudio.blob,
        mimeType: loadedAudio.mimeType,
        apiKey
      });

      setTranscript(rawText);
      toast.success('¡Audio transcrito con éxito!');
    } catch (err) {
      if (err.message === 'NEEDS_API_KEY') {
        setIsApiKeyModalOpen(true);
        toast.info('Configura tu clave de Gemini API para transcribir audio');
      } else {
        console.error(err);
        toast.error(err.message || 'Error al transcribir el audio');
      }
    } finally {
      setIsTranscribingAudio(false);
    }
  };

  // Refine transcription text
  const handleRefine = async (customTranscript = null) => {
    const textToRefine = customTranscript !== null ? customTranscript : transcript;

    if (!textToRefine || !textToRefine.trim()) {
      toast.error('Carga primero la transcripción a corregir');
      return;
    }

    setIsRefining(true);
    setResult('');
    setHistory(['']);
    setHistoryIndex(0);

    abortControllerRef.current = new AbortController();

    try {
      await refineTranscript({
        transcript: textToRefine,
        example,
        apiKey,
        signal: abortControllerRef.current.signal,
        onChunk: (fullText) => {
          setResult(fullText);
        }
      });

      setHistory((prev) => [...prev, result]);
      setHistoryIndex(1);
      toast.success('¡Transcripción refinada con éxito!');
    } catch (err) {
      if (err.name === 'AbortError') {
        toast.info('Proceso cancelado');
        return;
      }
      if (err.message === 'NEEDS_API_KEY') {
        setIsApiKeyModalOpen(true);
        toast.info('Configura tu clave de Gemini API para comenzar a procesar');
      } else {
        console.error(err);
        toast.error(err.message || 'Error al refinar la transcripción');
      }
    } finally {
      setIsRefining(false);
    }
  };

  // Full 1-Click Pipeline: Transcribe Audio + Refine
  const handleTranscribeAndRefineAll = async () => {
    if (!loadedAudio) {
      toast.error('Carga primero un archivo de audio o graba con el micrófono.');
      return;
    }

    setIsTranscribingAudio(true);
    toast.info('Paso 1: Transcribiendo audio con IA...');

    try {
      const rawText = await transcribeAudio({
        audioBlob: loadedAudio.blob,
        mimeType: loadedAudio.mimeType,
        apiKey
      });

      setTranscript(rawText);
      setIsTranscribingAudio(false);
      toast.info('Paso 2: Refinando y formateando transcripción...');

      await handleRefine(rawText);
    } catch (err) {
      setIsTranscribingAudio(false);
      if (err.message === 'NEEDS_API_KEY') {
        setIsApiKeyModalOpen(true);
        toast.info('Configura tu clave de Gemini API para procesar el audio');
      } else {
        console.error(err);
        toast.error(err.message || 'Error en el procesamiento del audio');
      }
    }
  };

  // Export handlers
  const handleCopy = async () => {
    if (!result) return;
    try {
      await navigator.clipboard.writeText(result);
      toast.success('Copiado al portapapeles');
    } catch (err) {
      toast.error('No se pudo copiar');
    }
  };

  const handleDownloadTxt = () => {
    if (!result) return;
    const blob = new Blob([result], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'transcripcion-corregida.txt';
    a.click();
    URL.revokeObjectURL(url);
    toast.success('Archivo TXT descargado');
  };

  const handleDownloadPdf = async () => {
    if (!result) {
      toast.error('No hay texto para exportar');
      return;
    }
    try {
      await exportToPdf(result, 'transcripcion-corregida.pdf', {
        template: pdfTemplate,
        title: pdfTitle,
        subtitle: pdfSubtitle
      });
      toast.success('Documento PDF generado');
    } catch (err) {
      console.error(err);
      toast.error('No se pudo generar el PDF');
    }
  };

  const handleDownloadDocx = () => {
    if (!result) return;
    const formattedHtml = `<!DOCTYPE html>
<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
<head><meta charset='utf-8'><title>${pdfTitle}</title>
<style>
  body { font-family: 'Calibri', 'Segoe UI', sans-serif; font-size: 11pt; line-height: 1.5; color: #111; }
  h1 { font-size: 18pt; color: #000; margin-bottom: 4pt; }
  .subtitle { font-size: 10pt; color: #666; margin-bottom: 16pt; }
  p { margin-bottom: 10pt; }
  .speaker { font-weight: bold; color: #1a365d; }
</style>
</head>
<body>
  <h1>${pdfTitle}</h1>
  ${pdfSubtitle ? `<div class='subtitle'>${pdfSubtitle}</div>` : ''}
  <hr style="border: 0; border-top: 1px solid #ccc; margin-bottom: 18pt;" />
  ${result.split('\n\n').map(p => `<p>${p.replace(/\n/g, '<br/>')}</p>`).join('')}
</body></html>`;

    const blob = new Blob([formattedHtml], { type: 'application/msword;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'transcripcion-corregida.doc';
    a.click();
    URL.revokeObjectURL(url);
    toast.success('Documento Word descargado');
  };

  const resultWords = result.trim() ? result.trim().split(/\s+/).length : 0;
  const resultChars = result.length;

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col font-sans">
      <ToastContainer />

      {/* Top Header */}
      <Header
        onOpenApiKeyModal={() => setIsApiKeyModalOpen(true)}
        hasApiKey={!!apiKey}
        onSelectTemplate={(sampleExample, sampleTranscript) => {
          setExample(sampleExample);
          setTranscript(sampleTranscript);
        }}
      />

      {/* Deploy / Public link banner button */}
      <div className="bg-zinc-900 text-zinc-100 text-xs py-2 px-6">
        <div className="mx-auto max-w-6xl flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="flex h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
            <span>Servidor local activo en <strong>http://localhost:3001</strong></span>
          </div>
          <button
            onClick={() => setIsDeployModalOpen(true)}
            className="flex items-center gap-1.5 bg-white/10 hover:bg-white/20 text-white px-2.5 py-1 rounded transition"
          >
            <Globe className="w-3.5 h-3.5" />
            <span>¿Cómo publicarla en la web?</span>
          </button>
        </div>
      </div>

      <main className="flex-1 mx-auto max-w-6xl w-full px-6 py-8 space-y-6">
        {/* Audio Banner if Audio File is Loaded */}
        {loadedAudio && (
          <div className="rounded-xl border border-indigo-200 bg-indigo-50/70 p-4 shadow-2xs flex flex-wrap items-center justify-between gap-3 animate-in fade-in duration-300">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-600 text-white">
                <Music className="h-5 w-5" />
              </div>
              <div>
                <div className="text-sm font-bold text-indigo-950 flex items-center gap-2">
                  <span>Audio cargado: {loadedAudio.name}</span>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800 font-medium">
                    {loadedAudio.sizeMb} MB
                  </span>
                </div>
                <div className="text-xs text-indigo-700">
                  Listo para transcribir y refinar automáticamente con el ejemplo.
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleTranscribeAudioOnly}
                disabled={isTranscribingAudio || isRefining}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border border-indigo-300 bg-white text-indigo-900 hover:bg-indigo-50 transition disabled:opacity-50"
              >
                {isTranscribingAudio ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
                <span>Transcribir Audio</span>
              </button>

              <button
                type="button"
                onClick={handleTranscribeAndRefineAll}
                disabled={isTranscribingAudio || isRefining}
                className="inline-flex items-center gap-1.5 px-4 py-1.5 text-xs font-bold rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 transition disabled:opacity-50 shadow-xs"
              >
                {isTranscribingAudio || isRefining ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Sparkles className="w-3.5 h-3.5" />
                )}
                <span>Transcribir y Refinar en 1 Paso</span>
              </button>

              <button
                type="button"
                onClick={() => setLoadedAudio(null)}
                className="text-indigo-400 hover:text-indigo-600 p-1"
                title="Quitar audio"
              >
                ✕
              </button>
            </div>
          </div>
        )}

        {/* Step 1: Input Columns Grid */}
        <div className="grid gap-6 md:grid-cols-2">
          {/* Card 1: Original Transcription */}
          <div className="rounded-xl border border-border bg-card p-5 shadow-2xs space-y-3">
            <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
              <div className="flex items-center gap-2 text-base font-semibold text-zinc-900">
                <FileText className="h-4 w-4 text-zinc-600" />
                <span>Transcripción original o Audio</span>
              </div>
              {isTranscribingAudio && (
                <span className="flex items-center gap-1 text-xs font-medium text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full animate-pulse">
                  <Loader2 className="w-3 h-3 animate-spin" />
                  Transcribiendo audio…
                </span>
              )}
            </div>
            <FileUploadDropzone
              label="Pega el texto, sube documentos (TXT/PDF/DOCX) o graba/sube AUDIO (MP3/WAV/M4A)"
              value={transcript}
              onChange={setTranscript}
              allowAudio={true}
              onAudioFileLoaded={handleAudioLoaded}
              placeholder={`Speaker 1: hola eh como estas gracias por venir...\nSpeaker 2: bien y tu gracias por invitarme...`}
            />
          </div>

          {/* Card 2: Desired Example Template */}
          <div className="rounded-xl border border-border bg-card p-5 shadow-2xs space-y-3">
            <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
              <div className="flex items-center gap-2 text-base font-semibold text-zinc-900">
                <Wand2 className="h-4 w-4 text-zinc-600" />
                <span>Ejemplo del formato deseado</span>
                {hasSavedTemplate && (
                  <span className="ml-2 rounded-full bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary">
                    Plantilla guardada
                  </span>
                )}
              </div>
            </div>

            <FileUploadDropzone
              label="Sube TXT, PDF o DOCX, o pega el formato de ejemplo"
              value={example}
              onChange={setExample}
              allowedExtensions={['txt', 'pdf', 'docx']}
              placeholder={`Orador 1: Hola, ¿cómo estás? Gracias por asistir.\nOrador 2: Muy bien, gracias por la invitación.`}
            />

            <div className="flex flex-wrap gap-2 pt-1">
              <button
                type="button"
                onClick={handleSaveDefaultExample}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md border border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50 transition shadow-2xs"
              >
                <Bookmark className="w-3.5 h-3.5 text-zinc-500" />
                <span>Guardar como predeterminada</span>
              </button>

              {hasSavedTemplate && (
                <button
                  type="button"
                  onClick={handleClearDefaultExample}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md text-red-600 hover:bg-red-50 transition"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Borrar plantilla</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Step 2: Action Button */}
        <div className="flex justify-center py-2 gap-3">
          <button
            type="button"
            onClick={() => handleRefine()}
            disabled={isRefining || !transcript.trim() || isTranscribingAudio}
            className="inline-flex items-center gap-2 px-8 py-3.5 text-sm font-semibold rounded-xl bg-zinc-900 text-white hover:bg-zinc-800 disabled:opacity-50 disabled:pointer-events-none transition shadow-sm"
          >
            {isRefining ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-zinc-400" />
                <span>Refinando con IA…</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>Refinar transcripción</span>
              </>
            )}
          </button>
        </div>

        {/* Step 3: Result & Interactive Editor Card */}
        <div className="rounded-xl border border-border bg-card p-5 shadow-2xs space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-zinc-100 pb-3">
            <div className="flex items-center gap-2">
              <span className="text-base font-semibold text-zinc-900">Resultado</span>
              {isRefining && (
                <span className="flex items-center gap-1 text-xs text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full animate-pulse">
                  Generando respuesta en tiempo real…
                </span>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handleCopy}
                disabled={!result}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50 transition shadow-2xs disabled:opacity-40"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>Copiar</span>
              </button>

              <button
                type="button"
                onClick={handleDownloadTxt}
                disabled={!result}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50 transition shadow-2xs disabled:opacity-40"
              >
                <Download className="w-3.5 h-3.5" />
                <span>TXT</span>
              </button>

              <button
                type="button"
                onClick={handleDownloadDocx}
                disabled={!result}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50 transition shadow-2xs disabled:opacity-40"
              >
                <FileText className="w-3.5 h-3.5 text-blue-600" />
                <span>DOCX</span>
              </button>

              <button
                type="button"
                onClick={handleDownloadPdf}
                disabled={!result}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-zinc-900 text-white hover:bg-zinc-800 transition shadow-2xs disabled:opacity-40"
              >
                <FileDown className="w-3.5 h-3.5" />
                <span>PDF</span>
              </button>
            </div>
          </div>

          {/* PDF Template & Metadata Controls */}
          <div className="flex flex-wrap items-end gap-3 rounded-lg border border-zinc-200 bg-zinc-50/60 p-3 text-xs">
            <div className="flex flex-col gap-1">
              <span className="font-semibold text-zinc-600">Plantilla PDF</span>
              <select
                value={pdfTemplate}
                onChange={(e) => setPdfTemplate(e.target.value)}
                className="h-8 px-2.5 rounded border border-zinc-300 bg-white text-zinc-800 text-xs focus:outline-none"
              >
                {PDF_TEMPLATES.map((tmpl) => (
                  <option key={tmpl.id} value={tmpl.id}>
                    {tmpl.label} — {tmpl.description}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex flex-col gap-1">
              <span className="font-semibold text-zinc-600">Título</span>
              <input
                type="text"
                value={pdfTitle}
                onChange={(e) => setPdfTitle(e.target.value)}
                placeholder="Transcripción"
                disabled={pdfTemplate === 'plain'}
                className="h-8 w-48 px-2.5 rounded border border-zinc-300 bg-white text-zinc-800 text-xs focus:outline-none disabled:opacity-40"
              />
            </div>

            <div className="flex flex-col gap-1">
              <span className="font-semibold text-zinc-600">Subtítulo / Asunto</span>
              <input
                type="text"
                value={pdfSubtitle}
                onChange={(e) => setPdfSubtitle(e.target.value)}
                placeholder="Opcional (ej. Sesión N° 4)"
                disabled={pdfTemplate === 'plain'}
                className="h-8 w-56 px-2.5 rounded border border-zinc-300 bg-white text-zinc-800 text-xs focus:outline-none disabled:opacity-40"
              />
            </div>
          </div>

          {/* Advanced Editing Toolbar */}
          <EditorToolbar
            onUndo={handleUndo}
            onRedo={handleRedo}
            canUndo={historyIndex > 0}
            canRedo={historyIndex < history.length - 1}
            disabled={!result}
            onTransformText={(transformFn) => {
              const newText = transformFn(result);
              updateResultWithHistory(newText);
            }}
          />

          {/* Live Editable Textarea */}
          <div className="space-y-2">
            <textarea
              ref={editorRef}
              value={result}
              onChange={(e) => updateResultWithHistory(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="La transcripción corregida aparecerá aquí… Puedes editarla libremente en cualquier momento."
              rows={16}
              className="w-full resize-y rounded-lg border border-zinc-200 bg-white p-4 font-mono text-sm leading-relaxed text-zinc-900 outline-none focus:border-zinc-400 placeholder:text-zinc-400 shadow-2xs"
            />

            <div className="flex items-center justify-between text-xs text-zinc-500 px-1">
              <span className="text-zinc-400 italic">
                Tip: Puedes editar directamente el texto arriba o usar Ctrl+Z para deshacer cambios.
              </span>
              <div className="flex items-center gap-3 font-medium">
                <span>{resultWords} palabras</span>
                <span>·</span>
                <span>{resultChars} caracteres</span>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-white py-4 mt-8">
        <div className="mx-auto max-w-6xl px-6 flex items-center justify-between text-xs text-zinc-500">
          <span>Refinador de Transcripciones · Corrección de sintaxis y coherencia sin resumir</span>
          <div className="flex items-center gap-4">
            <button onClick={() => setIsDeployModalOpen(true)} className="hover:underline text-zinc-600">
              Guía de Despliegue
            </button>
            <button onClick={() => setIsApiKeyModalOpen(true)} className="hover:underline text-zinc-600">
              Configuración de IA
            </button>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <ApiKeyModal
        isOpen={isApiKeyModalOpen}
        onClose={() => setIsApiKeyModalOpen(false)}
        currentKey={apiKey}
        onSaveKey={(newKey) => {
          setApiKey(newKey);
          if (newKey) {
            localStorage.setItem(STORAGE_GEMINI_KEY, newKey);
          } else {
            localStorage.removeItem(STORAGE_GEMINI_KEY);
          }
        }}
      />

      {/* Deploy / Hosting Guide Modal */}
      {isDeployModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="relative w-full max-w-xl rounded-xl bg-white p-6 shadow-2xl border border-zinc-200 space-y-4">
            <button
              onClick={() => setIsDeployModalOpen(false)}
              className="absolute right-4 top-4 text-zinc-400 hover:text-zinc-600 p-1"
            >
              ✕
            </button>

            <div className="flex items-center gap-3 mb-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-zinc-900 text-white">
                <Globe className="h-5 w-5" />
              </div>
              <div>
                <h2 className="text-base font-bold text-zinc-900">Cómo publicar tu aplicación en la Web</h2>
                <p className="text-xs text-zinc-500">Opciones gratuitas para tener tu URL pública accesible desde cualquier lugar</p>
              </div>
            </div>

            <div className="space-y-3 text-xs text-zinc-700">
              <div className="p-3 rounded-lg border border-zinc-200 bg-zinc-50 space-y-1">
                <div className="font-bold text-zinc-900 flex items-center justify-between">
                  <span>Opción 1: Vercel / Netlify (100% Gratis y Recomendado)</span>
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 font-semibold px-2 py-0.5 rounded">Recomendado</span>
                </div>
                <p>
                  Sube el proyecto a GitHub y conéctalo en Vercel o Netlify. Se publica automáticamente con un enlace <code>https://tu-proyecto.vercel.app</code> con certificado SSL incluido.
                </p>
              </div>

              <div className="p-3 rounded-lg border border-zinc-200 bg-zinc-50 space-y-1">
                <div className="font-bold text-zinc-900">Opción 2: Render.com / Railway (Para ejecutar con servidor Node)</div>
                <p>
                  Si deseas que el backend Express gestione la API con la variable <code>GEMINI_API_KEY</code> en el servidor, puedes crear un servicio web gratuito en Render.com indicando <code>node server.js</code> como comando de inicio.
                </p>
              </div>

              <div className="p-3 rounded-lg border border-zinc-200 bg-zinc-50 space-y-1">
                <div className="font-bold text-zinc-900">Opción 3: Probar online ahora mismo con Túnel Temporal</div>
                <p>
                  Puedes generar una URL pública temporal para compartirla o probarla desde tu celular ejecutando en la terminal:
                  <br />
                  <code className="bg-zinc-200 text-zinc-800 px-1 py-0.5 rounded text-[11px] block mt-1">npx localtunnel --port 3001</code>
                </p>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setIsDeployModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold rounded-lg bg-zinc-900 text-white hover:bg-zinc-800 transition"
              >
                Entendido
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
