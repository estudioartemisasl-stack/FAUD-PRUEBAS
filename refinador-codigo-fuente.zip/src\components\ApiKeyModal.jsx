import React, { useState } from 'react';
import { Key, ExternalLink, Check, AlertTriangle, X } from 'lucide-react';
import { toast } from './Toast';

export function ApiKeyModal({ isOpen, onClose, onSaveKey, currentKey }) {
  const [apiKey, setApiKey] = useState(currentKey || '');
  const [isTesting, setIsTesting] = useState(false);

  if (!isOpen) return null;

  const handleSave = () => {
    onSaveKey(apiKey.trim());
    toast.success('Clave de API guardada correctamente');
    onClose();
  };

  const handleClear = () => {
    setApiKey('');
    onSaveKey('');
    toast.info('Clave de API eliminada');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-md rounded-xl bg-white p-6 shadow-2xl border border-zinc-200">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 text-zinc-400 hover:text-zinc-600 p-1"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-zinc-900 text-white">
            <Key className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-zinc-900">Configuración de Gemini API</h2>
            <p className="text-xs text-zinc-500">Motor de inteligencia artificial para el refinador</p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-zinc-700 uppercase tracking-wider mb-1.5">
              Google Gemini API Key
            </label>
            <input
              type="password"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder="AIzaSy..."
              className="w-full px-3 py-2 text-sm rounded-lg border border-zinc-300 focus:outline-none focus:ring-2 focus:ring-zinc-900/20 focus:border-zinc-900"
            />
            <p className="mt-1.5 text-xs text-zinc-500">
              Tu clave se almacena de forma segura en tu navegador (localStorage) y nunca se comparte.
            </p>
          </div>

          <div className="rounded-lg bg-zinc-50 p-3 border border-zinc-200 text-xs text-zinc-600 space-y-1.5">
            <div className="font-semibold text-zinc-800 flex items-center gap-1.5">
              <span>¿No tienes una API Key gratuita?</span>
            </div>
            <p>
              Puedes obtener una clave gratuita con altos límites de uso directamente en Google AI Studio:
            </p>
            <a
              href="https://aistudio.google.com/app/apikey"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 text-blue-600 hover:underline font-medium pt-1"
            >
              <span>Generar clave en Google AI Studio</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>

          <div className="flex items-center justify-between pt-2">
            {currentKey ? (
              <button
                type="button"
                onClick={handleClear}
                className="text-xs text-red-600 hover:underline font-medium"
              >
                Eliminar clave
              </button>
            ) : <div />}

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-3.5 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 text-zinc-700 hover:bg-zinc-100 transition"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleSave}
                className="px-4 py-1.5 text-xs font-semibold rounded-lg bg-zinc-900 text-white hover:bg-zinc-800 transition"
              >
                Guardar
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
