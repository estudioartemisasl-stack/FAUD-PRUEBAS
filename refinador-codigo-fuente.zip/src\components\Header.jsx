import React from 'react';
import { Wand2, Key, Sparkles, BookOpen } from 'lucide-react';
import { SAMPLE_TEMPLATES, SAMPLE_TRANSCRIPT } from '../lib/defaultTemplates';
import { toast } from './Toast';

export function Header({ onOpenApiKeyModal, onSelectTemplate, hasApiKey }) {
  return (
    <header className="border-b border-border bg-white">
      <div className="mx-auto max-w-6xl px-6 py-5 flex flex-wrap items-center justify-between gap-4">
        {/* App Title & Icon */}
        <div className="flex items-center gap-3.5">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-sm">
            <Wand2 className="h-5 w-5" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-foreground flex items-center gap-2">
              Refinador de Transcripciones
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-zinc-100 text-zinc-700 border border-zinc-200">
                IA Avanzada
              </span>
            </h1>
            <p className="text-sm text-muted-foreground">
              Corrige y da formato a tus transcripciones usando un ejemplo de referencia.
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2.5">
          {/* Preset selector dropdown */}
          <div className="relative group">
            <button
              type="button"
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-border bg-white text-zinc-700 hover:bg-zinc-50 transition"
            >
              <BookOpen className="w-3.5 h-3.5 text-zinc-500" />
              <span>Cargar Ejemplo de Prueba</span>
            </button>
            <div className="absolute right-0 mt-1 w-64 rounded-lg border border-border bg-white p-1.5 shadow-lg hidden group-hover:block hover:block z-50">
              <div className="text-[11px] font-semibold text-zinc-400 px-2 py-1 uppercase tracking-wider">
                Plantillas de Ejemplo
              </div>
              {SAMPLE_TEMPLATES.map((tmpl) => (
                <button
                  key={tmpl.id}
                  onClick={() => {
                    onSelectTemplate(tmpl.text, SAMPLE_TRANSCRIPT);
                    toast.success(`Cargado: ${tmpl.name}`);
                  }}
                  className="w-full text-left px-2.5 py-1.5 text-xs text-zinc-700 hover:bg-zinc-100 rounded-md transition"
                >
                  {tmpl.name}
                </button>
              ))}
            </div>
          </div>

          {/* API Key settings button */}
          <button
            onClick={onOpenApiKeyModal}
            className={`flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border transition ${
              hasApiKey
                ? 'border-emerald-200 bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
                : 'border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50'
            }`}
          >
            <Key className="w-3.5 h-3.5" />
            <span>{hasApiKey ? 'API Key Configurada' : 'Configurar Gemini'}</span>
          </button>
        </div>
      </div>
    </header>
  );
}
