import React, { useState, useRef, useEffect } from 'react';
import { Upload, FileText, Loader2, X, Mic, Square, Music } from 'lucide-react';
import { parseUploadedFile } from '../lib/fileParsers';
import { toast } from './Toast';

export function FileUploadDropzone({
  label,
  value,
  onChange,
  placeholder,
  allowedExtensions = ['txt', 'srt', 'vtt', 'pdf', 'docx'],
  allowAudio = false,
  onAudioFileLoaded = null
}) {
  const [isDragging, setIsDragging] = useState(false);
  const [isLoadingFile, setIsLoadingFile] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);

  const fileInputRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const timerIntervalRef = useRef(null);

  const effectiveExtensions = allowAudio
    ? [...allowedExtensions, 'mp3', 'wav', 'm4a', 'ogg', 'webm', 'aac']
    : allowedExtensions;

  // Cleanup timer on unmount
  useEffect(() => {
    return () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    };
  }, []);

  const handleFile = async (file) => {
    if (!file) return;
    const ext = file.name.split('.').pop().toLowerCase();
    const isAudio = ['mp3', 'wav', 'm4a', 'ogg', 'webm', 'aac'].includes(ext);

    if (isAudio && allowAudio && onAudioFileLoaded) {
      onAudioFileLoaded(file);
      return;
    }

    if (!effectiveExtensions.includes(ext)) {
      toast.error(`Formato no compatible (.${ext}). Usa: ${effectiveExtensions.join(', ')}`);
      return;
    }

    try {
      setIsLoadingFile(true);
      const text = await parseUploadedFile(file);
      if (!text || !text.trim()) {
        toast.error('El archivo está vacío o no contiene texto legible.');
        return;
      }
      onChange(text);
      toast.success(`Archivo cargado: ${file.name}`);
    } catch (err) {
      console.error(err);
      toast.error(`No se pudo leer el archivo: ${err.message}`);
    } finally {
      setIsLoadingFile(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  // Microphone recording
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunksRef.current = [];
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        stream.getTracks().forEach((track) => track.stop());
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        if (onAudioFileLoaded) {
          onAudioFileLoaded(audioBlob, 'grabacion_microfono.webm');
        }
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingSeconds(0);
      timerIntervalRef.current = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
      toast.info('Grabando audio del micrófono...');
    } catch (err) {
      console.error(err);
      toast.error('No se pudo acceder al micrófono. Verifica los permisos de tu navegador.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    }
  };

  const formatTimer = (sec) => {
    const mins = Math.floor(sec / 60);
    const remaining = sec % 60;
    return `${mins.toString().padStart(2, '0')}:${remaining.toString().padStart(2, '0')}`;
  };

  const wordCount = value.trim() ? value.trim().split(/\s+/).length : 0;
  const charCount = value.length;

  return (
    <div className="space-y-2">
      {/* Upload trigger bar & File input */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <label className="text-xs font-semibold text-zinc-500 uppercase tracking-wider">
          {label}
        </label>
        <div className="flex items-center gap-2">
          <input
            type="file"
            ref={fileInputRef}
            onChange={(e) => handleFile(e.target.files[0])}
            accept={effectiveExtensions.map((e) => `.${e}`).join(',')}
            className="hidden"
          />

          {allowAudio && (
            <>
              {isRecording ? (
                <button
                  type="button"
                  onClick={stopRecording}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md bg-red-600 text-white hover:bg-red-700 transition animate-pulse"
                >
                  <Square className="w-3.5 h-3.5 fill-current" />
                  <span>Detener ({formatTimer(recordingSeconds)})</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={startRecording}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md border border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50 transition shadow-2xs"
                  title="Grabar directamente con el micrófono"
                >
                  <Mic className="w-3.5 h-3.5 text-red-500" />
                  <span>Grabar</span>
                </button>
              )}
            </>
          )}

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={isLoadingFile}
            className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md border border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50 transition shadow-2xs disabled:opacity-50"
          >
            {isLoadingFile ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Upload className="w-3.5 h-3.5 text-zinc-500" />
            )}
            <span>{allowAudio ? 'Subir archivo o audio' : 'Subir archivo'}</span>
          </button>

          {value && (
            <button
              type="button"
              onClick={() => onChange('')}
              className="text-zinc-400 hover:text-zinc-600 p-1"
              title="Borrar texto"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Drop area & Textarea */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        className={`relative rounded-lg border transition ${
          isDragging
            ? 'border-primary ring-2 ring-primary/20 bg-zinc-50'
            : 'border-zinc-200 bg-white focus-within:border-zinc-400'
        }`}
      >
        <textarea
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          rows={11}
          className="w-full resize-y rounded-lg p-3.5 text-sm font-mono leading-relaxed bg-transparent outline-none placeholder:text-zinc-400 text-zinc-800"
        />

        {isDragging && (
          <div className="absolute inset-0 flex items-center justify-center bg-white/90 rounded-lg pointer-events-none">
            <div className="flex flex-col items-center gap-2 text-primary font-medium text-sm">
              <Upload className="w-6 h-6 animate-bounce" />
              <span>Suelta aquí tu archivo de texto o audio para procesarlo</span>
            </div>
          </div>
        )}
      </div>

      {/* Word / Char counter */}
      <div className="flex items-center justify-between text-xs text-zinc-400 px-1">
        <span>Formatos: {effectiveExtensions.map((e) => e.toUpperCase()).join(', ')}</span>
        <div className="flex items-center gap-3">
          <span>{wordCount} palabras</span>
          <span>·</span>
          <span>{charCount} caracteres</span>
        </div>
      </div>
    </div>
  );
}
